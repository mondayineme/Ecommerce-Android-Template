package com.example.ciyashop.utils;

import com.ciyashop.library.apicall.URLS;

public class APIS {

    //TODO:Copy and Paste URL and Key Below from Admin Panel.
//    public final        String APP_URL            = "http://ciyashop.example.com"; //TODO:Application URL
    /*
    public final        String APP_URL            = "https://feeldi.com"; //TODO:Application URL
    public final        String WOO_MAIN_URL       = APP_URL + "wp-json/wc/v2/"; //TODO:Woocommerce API Path
    public final        String MAIN_URL           = APP_URL + "wp-json/pgs-woo-api/v1/"; //TODO:PGS Woo API Path
    public static final String CONSUMERKEY        = "MoTZJzo95CkG";
    public static final String CONSUMERSECRET     = "4GrGsq0XNuDD03DgY2E2qoShniQJxIfisqztfy8Wf2zbvyha";
    public static final String OAUTH_TOKEN        = "ev1HXLxTS0PInZDmoWbeb6fH";
    public static final String OAUTH_TOKEN_SECRET = "sMUFdZVblFVTPMvV2gfDr2LKm47DBZzpTfs30O9aLmVt4ICp";
    public static final String WOOCONSUMERKEY     = "ck_2483703ca2418770d49be1900125cddf757861d2";
    public static final String WOOCONSUMERSECRET  = "cs_2940f5359c6738835d842f75434a199e707c1a1b";
    public static final String version = "1.0";

     */
    public final String APP_URL = "https://feeldi.com/";
    public final String WOO_MAIN_URL = APP_URL + "wp-json/wc/v2/";
    public final String MAIN_URL = APP_URL + "wp-json/pgs-woo-api/v1/";

    public static final String CONSUMERKEY = "MoTZJzo95CkG";
    public static final String CONSUMERSECRET = "4GrGsq0XNuDD03DgY2E2qoShniQJxIfisqztfy8Wf2zbvyha";
    public static final String OAUTH_TOKEN = "ev1HXLxTS0PInZDmoWbeb6fH";
    public static final String OAUTH_TOKEN_SECRET = "sMUFdZVblFVTPMvV2gfDr2LKm47DBZzpTfs30O9aLmVt4ICp";

    public static final String WOOCONSUMERKEY = "ck_2483703ca2418770d49be1900125cddf757861d2";
    public static final String WOOCONSUMERSECRET = "cs_2940f5359c6738835d842f75434a199e707c1a1b";
    public static final String version="3.2.3";

    public APIS() {
        URLS.APP_URL = APP_URL;
        URLS.NATIVE_API = APP_URL + "wp-json/wc/v3/";
        URLS.WOO_MAIN_URL = WOO_MAIN_URL;
        URLS.MAIN_URL = MAIN_URL;
        URLS.version = version;
        URLS.CONSUMERKEY = CONSUMERKEY;
        URLS.CONSUMERSECRET = CONSUMERSECRET;
        URLS.OAUTH_TOKEN = OAUTH_TOKEN;
        URLS.OAUTH_TOKEN_SECRET = OAUTH_TOKEN_SECRET;
        URLS.WOOCONSUMERKEY = WOOCONSUMERKEY;
        URLS.WOOCONSUMERSECRET = WOOCONSUMERSECRET;
    }
}