package com.example.ciyashop.interfaces;

/**
 * Created by Bhumi Shah on 11/7/2017.
 */

public interface OnItemClickListner {
    public void onItemClick(int position,String value,int outerpos);


}

