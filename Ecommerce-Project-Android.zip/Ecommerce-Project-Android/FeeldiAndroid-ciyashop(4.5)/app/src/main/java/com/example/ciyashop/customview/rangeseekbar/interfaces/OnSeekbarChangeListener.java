package com.example.ciyashop.customview.rangeseekbar.interfaces;

/**
 * Created by owais.ali on 7/14/2016.
 */
public interface OnSeekbarChangeListener {
    void valueChanged(Number value);
}
