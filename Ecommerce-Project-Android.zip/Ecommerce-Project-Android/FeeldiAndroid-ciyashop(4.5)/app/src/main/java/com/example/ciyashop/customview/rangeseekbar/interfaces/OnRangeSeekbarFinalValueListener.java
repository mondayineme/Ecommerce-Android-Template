package com.example.ciyashop.customview.rangeseekbar.interfaces;

/**
 * Created by owais.ali on 7/14/2016.
 */
public interface OnRangeSeekbarFinalValueListener {
    void finalValue(Number minValue, Number maxValue);
}
